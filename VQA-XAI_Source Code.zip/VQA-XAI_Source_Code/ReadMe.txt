Project Title: Visual Question Answering for Medical Images with Explainable AI
Project Members: Deepananth K (195001027), Jayakrishnan S V (195001040)
Project Supervisor: Dr. S. Kavitha

-------------------------------------------------------------------------------------

Dataset Link: https://github.com/abachaa/VQA-Med-2019

-------------------------------------------------------------------------------------

Hardware Requirements:
1) Machines with Intel (i5, i7 or xeon) or AMD (Ryzen 3, Ryzen 5) processors
with a minimum of 8GB of RAM and 128GB of storage.
2) Nvidia GPU for hardware acceleration

Software Requirements:
1) Python 3.5 or higher
2) Compatible Nvidia GPU Drivers and Cuda Toolkit
3) Pytorch, Tensorflow >=2.8
4) LIME, SHAP

-------------------------------------------------------------------------------------

Implementation Files:

1)  File Name: VQA_Model_Training.ipynb (IPython Notebook)
    Input: Train and Validation Datasets
    Output: Trained VQA Model
    Description: This IPython Notebook has functions for Training the VQA
    Model using VGGNet for Image Feature Extraction, BERT Tokenizer for
    tokenizing the Question. The features are concatenated and a BERT Model
    is trained for Answer Generation using the concatenated features.

2)  File Name: Testing_and_Evalutaion.ipynb (IPython Notebook)
    Input: Trained VQA Model and Test Dataset
    Output: Performance Metrics
    Description: This notebook tests the trained VQA Model with the Test
    Dataset and evaluates it based on various performance metrics such as
    Accuracy, BLEU Score and WBSS.

3)  File Name: VQA_and_XAI.ipynb (IPython Notebook)
    Input: Trained VQA Model and set of images & quesions
    Output: Explanations
    Description: This notebook uses the Explainable AI techniques - LIME & SHAP to
    provide explanations to the output of the Trained VQA Model.

4) File Name: model-final.pt (Model File)
   Description: Trained VQA final model file

5) File Name: bert-tokenizer/vocab.txt (Vocabulary File)
   Description: Vocabulary file for tokenizing the question used along with BERT

-------------------------------------------------------------------------------------

Instructions:
1) Install required libraries
2) Load the implementation files in a Jupyter-Notebook environment or COLAB
3) Execute the cells in "VQA_Model_Training.ipynb" file to train the model. 
   This would save the trained models after each epoch
4) Use the trained model for executng files "Testing_and_Evalutaion.ipynb" and
   "VQA_and_XAI.ipynb"
5) The trained model file can be found for reference

-------------------------------------------------------------------------------------